#Fichier init de fonctions_ajouts_suppr afin de pouvoir tout importer avec *

#all est une variable de python, permettant de préciser les fichiers à importer
#si la commande from fonctions_ajouts_suppr import * est exécutée
__all__=["creer_choix","creer_lien","fonctions_annexes","generator","suppr_lien","suppr_choix"]
