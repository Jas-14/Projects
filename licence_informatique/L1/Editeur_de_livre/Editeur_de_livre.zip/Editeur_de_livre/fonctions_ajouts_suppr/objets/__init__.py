#Fichier init du package objets

#all est une variable de python, permettant de préciser les fichiers à importer
#si la commande from fonctions_ajouts_suppr import * est exécutée
__all__=["c_histoire","choix_tkinter","c_lien","paragraphe_tkinter"]
